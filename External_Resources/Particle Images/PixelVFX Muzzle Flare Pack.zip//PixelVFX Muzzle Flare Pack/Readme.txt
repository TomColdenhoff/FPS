You are free to use this muzzle flare pack in your projects.

If you would like to credit me then please credit like this:

Muzzle Flares From
PixelVFX
tinyurl.com/PixelVFX

Use this for whatever you want. its public domain. Credit would be nice though.


Thank you for using this pack. If you have any suggestions then please PM me on Reddit /u/H4MSTER

